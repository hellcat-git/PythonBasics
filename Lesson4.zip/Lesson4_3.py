print([el for el in range(20, 241) if el % 20 == 0])
