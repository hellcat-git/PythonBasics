li = ["life", 2021, 20.01, "is", True, "good"]
for i in li:
    print(str(type(i)))